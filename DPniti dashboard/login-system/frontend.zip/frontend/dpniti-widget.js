(function () {
    function createMessage(text, who) {
        const msg = document.createElement('div');
        msg.className = 'dpniti-msg ' + who;
        msg.textContent = text;
        return msg;
    }

    function botReply(input) {
        const message = input.toLowerCase();
        if (message.includes('timetable')) return 'You can open class or exam timetables from the dashboard cards.';
        if (message.includes('faculty')) return 'Go to the Faculty section from dashboard to view faculty details.';
        if (message.includes('student')) return 'Use the Students section to browse the student directory.';
        if (message.includes('contact')) return 'Please open the Contact Us page from the navbar for details.';
        return 'I can help you navigate dashboard, faculty, students, timetable and contact information.';
    }

    function initWidget() {
        if (document.querySelector('.dpniti-widget-root')) return;

        const root = document.createElement('div');
        root.className = 'dpniti-widget-root';

        const fabWrap = document.createElement('div');
        fabWrap.className = 'dpniti-fab-wrap';

        const prompt = document.createElement('div');
        prompt.className = 'dpniti-prompt';
        prompt.textContent = 'Hii i am DPniti how may i help you ?';

        const fab = document.createElement('button');
        fab.className = 'dpniti-fab';
        fab.setAttribute('aria-label', 'Open DPniti assistant');

        const fabImg = document.createElement('img');
        fabImg.src = 'dp.jpeg';
        fabImg.alt = 'DPniti assistant';
        fab.appendChild(fabImg);

        fabWrap.appendChild(prompt);
        fabWrap.appendChild(fab);
        root.appendChild(fabWrap);

        const panel = document.createElement('section');
        panel.className = 'dpniti-chat-panel';

        const header = document.createElement('div');
        header.className = 'dpniti-chat-header';

        const close = document.createElement('button');
        close.className = 'dpniti-minimize';
        close.textContent = 'x';
        close.setAttribute('aria-label', 'Minimize chat');

        const title = document.createElement('div');
        title.className = 'dpniti-chat-title';
        title.textContent = 'DPniti Assistant';

        header.appendChild(close);
        header.appendChild(title);

        const body = document.createElement('div');
        body.className = 'dpniti-chat-body';
        body.appendChild(createMessage('Hii i am DPniti how may i help you ?', 'bot'));

        const inputRow = document.createElement('div');
        inputRow.className = 'dpniti-chat-input';

        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = 'Type your message...';

        const send = document.createElement('button');
        send.type = 'button';
        send.textContent = 'Send';

        inputRow.appendChild(input);
        inputRow.appendChild(send);

        panel.appendChild(header);
        panel.appendChild(body);
        panel.appendChild(inputRow);

        root.appendChild(panel);
        document.body.appendChild(root);

        function openPanel() {
            panel.classList.add('open');
            fabWrap.style.display = 'none';
            input.focus();
        }

        function closePanel() {
            panel.classList.remove('open');
            fabWrap.style.display = 'flex';
        }

        function sendMessage() {
            const text = input.value.trim();
            if (!text) return;
            body.appendChild(createMessage(text, 'user'));
            input.value = '';
            const reply = botReply(text);
            window.setTimeout(function () {
                body.appendChild(createMessage(reply, 'bot'));
                body.scrollTop = body.scrollHeight;
            }, 250);
            body.scrollTop = body.scrollHeight;
        }

        fab.addEventListener('click', openPanel);
        prompt.addEventListener('click', openPanel);
        close.addEventListener('click', closePanel);
        send.addEventListener('click', sendMessage);
        input.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') sendMessage();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initWidget);
    } else {
        initWidget();
    }
})();
